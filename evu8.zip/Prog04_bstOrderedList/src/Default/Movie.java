package Default;



/**
* <Movie class where I can create movie objects that will later be compared>
*
* CSC 1351 Programming Project No <1>
* Section <2>
*
* @author <Ella Vu>
* @since <April 29th>
*
*/
public class Movie implements Comparable <Movie>{
	//Creating private members
	private String movieTitle;
	private int releaseYear;
	private String rating;
	private int movieReview;
	
	   /**
	    * <constructor for movie object>
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
	public Movie(String title, int year, String rating,int review ) {
		this.movieTitle = title;
		this.releaseYear = year;
		this.rating = rating;
		this.movieReview = review;
		}
	
	   /**
	    * <Gets title of movie object>
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
	public String geTitle() {
		return movieTitle;
	}
	
	   /**
	    * <Gets year of movie object>
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
	public int getYear() {
		return releaseYear;
	}
	
	   /**
	    * <Gets rating of movie object>
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
	public String getRating() {
		return rating;
	}
	
	   /**
	    * <Gets review of movie object>
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
	public int getReview() {
		return movieReview;
	}
	
	
	
	   /**
	    * <Compares movie objects based on their title then their release year>
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
	public int compareTo(Movie other) {
		// checking if movie titles are the same or different by using string classes
		// will return a negative number if current movie title is before other
		// will return positive number if current movie title is greater than other
		if(!this.movieTitle.equals(other.movieTitle)) {
			return this.movieTitle.compareTo(other.movieTitle);
		} else {
			// if movie titles are equal, will move on to compare release years
			//  will return a negative number if movie was released before other movie
			return Integer.compare(this.releaseYear,  other.releaseYear);
		}
	}
	
	   /**
	    * <Formats movie object and displays their data>
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
	public String toString() {
	    return "Title: " + movieTitle + "\n" +
	           "Year: " + releaseYear + "\n" +
	           "Rating: " + rating + "\n" +
	           "Review: " + movieReview + "\n";
	}
	
}



