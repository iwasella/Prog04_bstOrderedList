package Default;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


/**
* <Where the main method is held and where we input our file and output it reformatted>
*
* CSC 1351 Programming Project No <1>
* Section <2>
*
* @author <Ella Vu>
* @since <April 29th>
*
*/
public class Prog04_bstOrderedList {

    public static void main(String[] args) {
        bstOrderedList movieList = new bstOrderedList();
        Scanner userInputScanner = new Scanner(System.in);

        // Reading from the input file and populating the movieList
        Scanner fileScanner = null;
        while (true) {
            System.out.print("Enter input filename: ");
            String inputFilename = userInputScanner.nextLine();
            File inputFile = new File(inputFilename);
            
            if (!inputFile.exists()) {
                System.out.println("File specified <" + inputFilename + "> does not exist. Would you like to continue? <Y/N>: ");
                String userDecision = userInputScanner.nextLine();
                if (userDecision.equalsIgnoreCase("N")) {
                    System.out.println("Program exiting.");
                    return; // Exit the program
                }
            } else {
                try {
                    fileScanner = new Scanner(inputFile);
                    while (fileScanner.hasNextLine()) {
                        String line = fileScanner.nextLine();
                        String[] parts = line.split(",");
                        if (parts.length < 5) {
                            continue; // Skip invalid line
                        }
                        String operation = parts[0].trim();
                        String title = parts[1].trim();
                        int year = Integer.parseInt(parts[2].trim());
                        String rating = parts[3].trim();
                        int review = Integer.parseInt(parts[4].trim());

                        Movie movie = new Movie(title, year, rating, review);
                        if ("A".equalsIgnoreCase(operation)) {
                            movieList.add(movie);
                        } else if ("D".equalsIgnoreCase(operation)) {
                            movieList.remove(movie);
                        }
                    }
                } catch (FileNotFoundException e) {
                    System.out.println("An error occurred: " + e.getMessage());
                } finally {
                    if (fileScanner != null) {
                        fileScanner.close();
                    }
                }
                break;
            }
        }

        // Prompt for output file name and write the movieList to the file
        try {
            PrintWriter writer = getInputFile(userInputScanner);
            Comparable[] moviesArray = movieList.toArray("inOrder"); // For example, in-order
            writeMoviesToFile(moviesArray, writer);
            writer.close(); // Close the PrintWriter
        } catch (FileNotFoundException e) {
            System.out.println("File cannot be created or opened: " + e.getMessage());
        } finally {
            userInputScanner.close();
        }
    }

    
    /**
    * <Asks for file name and checks if it is there>
    *
    * CSC 1351 Programming Project No <2>
    * Section <2>
    *
    * @author <Ella Vu>
    * @since <April 29>
    *
    */
    public static PrintWriter getInputFile(Scanner userInputScanner) throws FileNotFoundException {
        while (true) {
            System.out.print("Enter output filename: ");
            String filename = userInputScanner.nextLine();
            try {
                return new PrintWriter(new File(filename));
            } catch (FileNotFoundException e) {
                System.out.println("Unable to create or open the file. Please check the file path and try again.");
                System.out.print("Do you want to try again? <Y/N>: ");
                String choice = userInputScanner.nextLine();
                if ("N".equalsIgnoreCase(choice)) {
                    throw e; // Rethrow the exception to exit the method
                }
            }
        }
    }

    /**
    * <This method allows me to write the movies into the output file >
    *
    * CSC 1351 Programming Project No <2>
    * Section <2>
    *
    * @author <Ella Vu>
    * @since <April 29>
    *
    */
    public static void writeMoviesToFile(Comparable[] movies, PrintWriter writer) {
        writer.println("Number of movies: " + movies.length + "\n");
        for (Comparable movie : movies) {
            writer.println(movie.toString());
            writer.println(); // Add a blank line between movie entries
        }
    }
}
