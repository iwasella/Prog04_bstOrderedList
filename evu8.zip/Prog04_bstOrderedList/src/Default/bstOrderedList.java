package Default;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
* <This will provide a binary search tree implementation of an ordered list>
*
* CSC 1351 Programming Project No <1>
* Section <2>
*
* @author <Ella Vu>
* @since <April 29th>
*
*/
public class bstOrderedList {

	class Node {
		public Node leftChild;
		public Comparable data;
		public Node rightChild;
		
		// node constructor 
	    public Node(Comparable newData) {
	        data = newData;
	        leftChild = null;
	        rightChild = null;
	    }
		}	
	
	private Node root; //root element in the binary search tree
	
	
	// public methods for bstOrderedList
	
    public bstOrderedList() {
        root = null;
    }
    
    
	   /**
	    * <Adds an object as a node to the tree >
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
    //  left subtree of a node contains only nodes with keys less than the node's key and vice verca for right
    public void add(Comparable newObject) {
    	  // Create a new Node with the newObject as its data
        Node newNode = new Node(newObject);
        
        // If the tree is empty, the new node will become the root of the tree
        if (root == null) {
            root = newNode;
        } else {
            // we will start at the root of the tree
            Node current = root;
            Node parent;
            while (true) {
                // Keep track of the parent node for later inserting
                parent = current;
                
                // Use compareTo which will help on whether to go left or right
                int cmp = newObject.compareTo(current.data);
                
                if (cmp < 0) { // if newObject is less than current.data
                    // Move to the left child
                    current = current.leftChild;
                    
                    // If the left child does not exist, insert the new node here
                    if (current == null) {
                        parent.leftChild = newNode;
                        return; // Node inserted, exit the method
                    }
                } else if (cmp > 0) { // newObject is greater than current.data
                    // Move to the right child
                    current = current.rightChild;
                    
                    // If the right child does not exist, insert the new node here
                    if (current == null) {
                        parent.rightChild = newNode;
                        return; // Node inserted, exit the method
                    }
                } else {
                    // If cmp is equal to 0, the newObject is equal to current.data
                    // we don't insert it
                    return; 
                }
            }
        }
    }
    
	   /**
	    * <Reomves an object(node) from the sub tree if it matches the data of a node >
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
    public void remove(Comparable newObject) {
        Node parent = root;
        Node current = root;
        boolean isLeftChild = true;

        // Find the node with the given object.
        while (current != null && current.data.compareTo(newObject) != 0) {
            parent = current;
            int compareResult = newObject.compareTo(current.data);

            if (compareResult < 0) {
                isLeftChild = true;
                current = current.leftChild;
            } else {
                isLeftChild = false;
                current = current.rightChild;
            }
        }

        // If current is null, the item was not found.
        if (current == null) return;

        // Node to be deleted is a leaf node.
        if (current.leftChild == null && current.rightChild == null) {
            if (current == root) {
                root = null;
            } else if (isLeftChild) {
                parent.leftChild = null;
            } else {
                parent.rightChild = null;
            }
        }
        // Node to be deleted has one child.
        else if (current.rightChild == null) {
            if (current == root) {
                root = current.leftChild;
            } else if (isLeftChild) {
                parent.leftChild = current.leftChild;
            } else {
                parent.rightChild = current.leftChild;
            }
        } else if (current.leftChild == null) {
            if (current == root) {
                root = current.rightChild;
            } else if (isLeftChild) {
                parent.leftChild = current.rightChild;
            } else {
                parent.rightChild = current.rightChild;
            }
        }
        // Node to be deleted has two children.
        else {
            // Find the replacement (in-order successor) for the current node.
            Node replacementParent = current;
            Node replacement = current.rightChild;
            while (replacement.leftChild != null) {
                replacementParent = replacement;
                replacement = replacement.leftChild;
            }

            // If the replacement is not the right child, adjust the replacementParent's leftChild.
            if (replacement != current.rightChild) {
                replacementParent.leftChild = replacement.rightChild;
                replacement.rightChild = current.rightChild;
            }
            // Adjust the replacement's left child.
            replacement.leftChild = current.leftChild;

            // Replace current with replacement in the parent.
            if (current == root) {
                root = replacement;
            } else if (isLeftChild) {
                parent.leftChild = replacement;
            } else {
                parent.rightChild = replacement;
            }
        }
    }

	   /**
	    * <Finds the size of the tree (number of elements) >
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
    public int size() {
        // If the tree is empty, return a count of 0.
        if (root == null) {
            return 0;
        }
        
        // starting count of nodes as 0.
        int count = 0;

        // We're gonna create a stack to hold nodes as we go along the tree.
        // This will allow us to return to each node's parent and help us keep track
        Stack<Node> stack = new Stack<>();

        // We're gonna start at the root of the tree
        Node current = root;
        
        // Continue the traversal until we have no more nodes to visit.
        // this is when the current node is null and the stack is empty.
        while (current != null || !stack.isEmpty()) {
            // go  to the leftmost node, and then we push all the nodes we pass onto the stack.
            while (current != null) {
                stack.push(current);
                current = current.leftChild;
            }

            // after reaching the leftmost node, pop the last node from the stack.
            current = stack.pop();
            // Increment the count since we've 'visited' this node.
            count++;

            // Switch to the right subtree of the node that has just been visited.
            current = current.rightChild;
        }
        
        // Return the total count of nodes which will be the "size" or how many elements we have 
        return count;
    }
    
	   /**
	    * <Checks if tree is empty>
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
    public boolean isEmpty() {
    	// the tree if empty if the root is null because there are no nodes in the tree
        return root == null;
    }
    
    
    
	   /**
	    * <Returns the toString values of the list objects in sorted order, separated by
semicolons, and delimited by brackets >
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
    public String toString() {
    	
        // Create an empty stack to keep track of nodes during traversal
        Stack<Node> stack = new Stack<>();
       
        // Start with the root node
        Node current = root;
        // Start the string representation with an opening bracket
        String result = "[";

        // Continue traversing until there are no nodes left (both current is null and stack is empty)
        while (current != null || !stack.isEmpty()) {
            // Push all left children onto the stack, and we go as deep as possible to the left
            while (current != null) {
                stack.push(current);
                current = current.leftChild;
            }

            // Since we've reached the end of a left branch, pop the stack to process the node
            current = stack.pop();
            // If the result string isn't just the opening bracket, we add a comma for separation
            if (!result.equals("[")) {
                result += ", "; // Add a comma and space before the next element
            }
            // Add the node's data to the result string
            result += current.data.toString();

            // Move to the right child after visiting a node
            current = current.rightChild;
        }
        
        // Close the string representation with a bracket
        result += "]";
        // Return the complete string representation of the BST
        return result;
    }
    
    
	   /**
	    * <Constructs the contents of the tree in order provided by sorting parameter: preOrder, inOrder, or postOrder>
	    *
	    * CSC 1351 Programming Project No <2>
	    * Section <2>
	    *
	    * @author <Ella Vu>
	    * @since <April 29>
	    *
	    */
    public Comparable[] toArray(String sorting) {
        List<Comparable> list = new ArrayList<>();

        // Check the sorting order requested
        if ("preOrder".equalsIgnoreCase(sorting)) {
            // Pre-order traversal using a stack
            Stack<Node> stack = new Stack<>();
            if (root != null) {
                stack.push(root); // Start with the root
            }
            while (!stack.isEmpty()) {
                Node current = stack.pop(); // Visit node
                list.add(current.data); // Add to the list
                // Push right and then left child to the stack to ensure left is processed first
                if (current.rightChild != null) {
                    stack.push(current.rightChild);
                }
                if (current.leftChild != null) {
                    stack.push(current.leftChild);
                }
            }
        } else if ("inOrder".equalsIgnoreCase(sorting)) {
            // In-order traversal using a stack
            Stack<Node> stack = new Stack<>();
            Node current = root;
            while (current != null || !stack.isEmpty()) {
                // Travel to the leftmost node
                while (current != null) {
                    stack.push(current);
                    current = current.leftChild;
                }
                // Visit node
                current = stack.pop();
                list.add(current.data); // Add to the list
                // Go to the right child
                current = current.rightChild;
            }
        } else if ("postOrder".equalsIgnoreCase(sorting)) {
            // Post-order traversal using two stacks
            Stack<Node> stack1 = new Stack<>();
            Stack<Node> stack2 = new Stack<>();
            if (root != null) {
                stack1.push(root); // Start with the root
            }
            while (!stack1.isEmpty()) {
                Node current = stack1.pop();
                stack2.push(current); // Push to the second stack to reverse order later
                // Push left and then right child to the first stack
                if (current.leftChild != null) {
                    stack1.push(current.leftChild);
                }
                if (current.rightChild != null) {
                    stack1.push(current.rightChild);
                }
            }
            // Reverse the order to get post-order
            while (!stack2.isEmpty()) {
                list.add(stack2.pop().data); // Add to the list
            }
        } else {
            // Throw an exception if the sorting order is not recognized
            throw new IllegalArgumentException("Invalid sorting order");
        }

        // Convert the list to an array and return
        return list.toArray(new Comparable[0]);
    }

    
}
